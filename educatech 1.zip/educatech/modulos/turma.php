<?php 
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    
    require_once('bancoConexao.php');

    $conexao = conectarBanco();
    
    function buscarTurma($idEscola, $ciclo, $turma){
        global $conexao;
        
        $sql = "SELECT * FROM turma WHERE idEscola = ".$idEscola;
        $sql .= " AND ciclo = '$ciclo' AND turma = '$turma'";
        
        $select = mysqli_query($conexao, $sql);
        
        if(mysqli_num_rows($select) == 1){
			$turma = mysqli_fetch_array($select);
            return $turma;
        } else {
            return null;
        }
    }
    
    function selecionarTodasTurmas($idEscola){
        global $conexao;
        
        $sql = "SELECT * FROM turma WHERE idEscola = '$idEscola' ORDER BY ciclo ASC";
        
        return mysqli_query($conexao, $sql);
        
        mysqli_close($conexao);
    }
    
    function cadastrarTurma($idEscola, $ciclo, $turma, $periodo){
        global $conexao;
        
        $sql = " INSERT INTO turma(idEscola, ciclo, turma, periodo) VALUES";
        $sql .= " ('$idEscola', '$ciclo', '$turma', '$periodo')";

    	return mysqli_query($conexao, $sql);
    	mysqli_close($conexao);
    }
    
    function registrarHorarioAula($idTurma, $idDisciplina, $aula, $diaSemana, $idUsuario){
        global $conexao;
        
        $sql = " INSERT INTO turma_disciplina(idTurma, idDisciplina, aula, diaSemana, idUsuario) VALUES";
        $sql .= " ('$idTurma', '$idDisciplina', '$aula', '$diaSemana', '$idUsuario')";
        
        return mysqli_query($conexao, $sql);
    	mysqli_close($conexao);
    }
    
    function registrarDocenteResponsavel($idTurma, $idDocente){
        global $conexao;
        
        $sql = " INSERT INTO turma_fund1_responsavel(idTurma, idUsuario) VALUES";
        $sql .= " ('$idTurma', '$idDocente')";
  
        return mysqli_query($conexao, $sql);
    	mysqli_close($conexao);
    }
    
    function verificarHorariosAula($idTurma){
        global $conexao;
        $sql = "SELECT * FROM turma_disciplina WHERE idTurma=".$idTurma;
        
        $resultado = mysqli_query($conexao, $sql);

        if(!mysqli_num_rows($resultado)  == 0){
    		return true;
        } else {
            return false;
        }
        mysqli_close($conexao);
    }
    
    function consultarDisciplinaPelaAula($idTurma, $aula, $dia){
        global $conexao;
        
        $sql = " SELECT * FROM turma_disciplina WHERE idTurma=".$idTurma;
        $sql .= " AND aula='$aula' AND diaSemana = '$dia' ";
        
        $resultado = mysqli_query($conexao, $sql);
            
        if(mysqli_num_rows($resultado)  == 1){
    		$gradeTurma = mysqli_fetch_array($resultado);
            return $gradeTurma;
        } else {
            return null;
        }
        mysqli_close($conexao);
    }
    
    function consultarDocentePorDisciplina($idTurma, $idDisciplina){
        global $conexao;
        
        $idDocenteResp = 0;
        
        $sql = " SELECT * FROM turma_disciplina WHERE idTurma=".$idTurma;
        $sql .= " AND idDisciplina='$idDisciplina' LIMIT 1";

        $resultado = mysqli_query($conexao, $sql);
            
        if(mysqli_num_rows($resultado)  == 1){
            $row = mysqli_fetch_array($resultado);
    		$idDocenteResp = $row['idUsuario'];
        } 
        
        return $idDocenteResp;
        mysqli_close($conexao);
    }
    
   
    function selecionarDocentesPorDisciplina($idDisciplina, $idEscola){
        global $conexao;
        
        /*Seleciona o id e nome do docente que leciona essa disciplina*/
        $sql = "SELECT usuario.idUsuario, usuario.nomeUsuario FROM `docente_disciplina` ";
        $sql .= "INNER JOIN disciplina ON disciplina.idDisciplina = docente_disciplina.idDisciplina ";
        $sql .= "INNER JOIN usuario ON usuario.idUsuario = docente_disciplina.idUsuario ";
        $sql .= "INNER JOIN escola ON usuario.idEscola = escola.idEscola ";
        $sql .= "WHERE docente_disciplina.idDisciplina = ".$idDisciplina;
        $sql .= " AND escola.idEscola =".$idEscola;
        $sql .= " ORDER BY usuario.nomeUsuario ASC";
        
        return mysqli_query($conexao, $sql);
        
        mysqli_close($conexao);
    }
    
    function selecionarRespTurma($idTurma){
        global $conexao;
        
        $idDocenteResp = 0;
        
        $sql = " SELECT * FROM turma_fund1_responsavel WHERE idTurma=".$idTurma;

        $resultado = mysqli_query($conexao, $sql);
            
        if(mysqli_num_rows($resultado)  == 1){
            $row = mysqli_fetch_array($resultado);
    		$idDocenteResp = $row['idUsuario'];
        } 
        
        return $idDocenteResp;
        mysqli_close($conexao);
    }
    
    function selecionarDisciplinas(){
        global $conexao;
        
        $sql = "SELECT * FROM `disciplina` WHERE idDisciplina != 1";
        
        return mysqli_query($conexao, $sql);
        
        mysqli_close($conexao);
    }
    
    function selecionarDisciplinasFundI(){
        global $conexao;
        
        $sql = "SELECT * FROM `disciplina` WHERE fundamental1 = 1";
        
        return mysqli_query($conexao, $sql);
        
        mysqli_close($conexao);
    }
    
    
    function selecionarDisciplinasFund2(){
        global $conexao;
        
        $sql = "SELECT * FROM disciplina WHERE fundamental2 = 1";
        
        return mysqli_query($conexao, $sql);
        
        mysqli_close($conexao);
    }
    
    
?>