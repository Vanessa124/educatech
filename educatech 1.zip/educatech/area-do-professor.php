<!DOCTYPE html>
<html lang="pt">
    <head>
        <title> EducaTech - Minhas turmas </title>
        <meta charset="utf-8">
        <link rel="stylesheet" href='css/style.css' type="text/css">
        <link rel="icon" type="image/png" href='imagens/icons8-escola-40.png'>
        <script src="js/jquery.min.js"></script>
        
        
    </head>

    <body id='body-fundo-escuro'>
        
        <div id='cabecalho'>
            <?php require_once('cabecalho-usuario.php') ?>
        </div>
        
        <div id='container-branco'>
            <div class='linha header-titulo'>
                Turmas lecionadas
            </div>
            
            <div class='linha linha-borda-prof'>
                <div class='col-lista-prof'>
                    <a href='listaAulas.html' target="_blank" class='link-azul'>
                        2º B
                    </a>
                </div>
                
                <div class='col-10-lista'>
                    <strong> Disciplina:  </strong> Nome da disciplina
                </div>
            </div>
            
            <div class='linha'>
                <div class='col-lista-prof'>
                    <a href='listaAulas.html' target="_blank" class='link-azul'>
                        6º A
                    </a>
                </div>
                
                <div class='col-10-lista'>
                    <strong> Disciplina:  </strong> Nome da disciplina
                </div>
            </div>
        </div>
        

    </body>
</html>