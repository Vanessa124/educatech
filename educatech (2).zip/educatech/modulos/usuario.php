<?php 
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    
    require_once('bancoConexao.php');

    $conexao = conectarBanco();

    function cadastrarUsuario($idEscola, $nomeUsuario, $cpfUsuario, $emailUsuario, $loginUsuario, $senhaUsuario, $tipoUsuario){
        global $conexao;
        
        $sql = " INSERT INTO usuario(idEscola, nomeUsuario, cpfUsuario, emailUSuario, loginUsuario, senhaUsuario, tipoUsuario) VALUES";
        $sql .= " ('$idEscola', '$nomeUsuario', '$cpfUsuario', '$emailUsuario', '$loginUsuario', '$senhaUsuario', '$tipoUsuario');";
        
        return mysqli_query($conexao, $sql);
        mysqli_close($conexao);
    }
    
    function autenticarUsuario($idEscola, $loginUsuario, $senhaUsuario){
        global $conexao;
        
        $sql = "SELECT * FROM usuario WHERE idEscola = ".$idEscola;
        $sql .= " AND loginUsuario = '$loginUsuario' AND senhaUsuario = '$senhaUsuario'";
        
        $select = mysqli_query($conexao, $sql);
        
        if(mysqli_num_rows($select)  == 1){
			$usuario = mysqli_fetch_array($select);
            return $usuario;
        } else {
            return null;
        }
        
        mysqli_close($conexao);
    }
    
    function selecionarUsuarioPorCPF($idEscola, $cpfUsuario){
        global $conexao;
        
        $sql = "SELECT * FROM usuario WHERE idEscola = ".$idEscola;
        $sql .= " AND cpfUsuario = '$cpfUsuario'";
        
        $select = mysqli_query($conexao, $sql);
        
        if(mysqli_num_rows($select)  == 1){
			$usuario = mysqli_fetch_array($select);
            return $usuario;
        } else {
            return null;
        }
        
        mysqli_close($conexao);
    }
    
    function selecionarTodosUsuarios($idEscola){
        global $conexao;
        
        $sql = "SELECT * FROM usuario WHERE idEscola =".$idEscola;
        $sql .= " ORDER BY nomeUsuario";
        
        $resultado = mysqli_query($conexao, $sql);
        
        return $resultado;
        mysqli_close($conexao);
    }
    

    function selecionarDisciplinasLecionadas($idUsuario){
        global $conexao;
        
        $sql = "SELECT * FROM docente_disciplina WHERE idUsuario=".$idUsuario;
        
        $resultado = mysqli_query($conexao, $sql);
        
        return $resultado;
        mysqli_close($conexao);
    }

    function selecionarTurmasLecionadas($idUsuario){
        global $conexao;
        
        $sql = "SELECT DISTINCT ud.idUsuario, t.idTurma, t.ciclo, t.turma, d.idDisciplina, d.nomeDisciplina";
        $sql .= " FROM `docente_disciplina` AS ud";
        $sql .= " INNER JOIN disciplina AS d ON d.idDisciplina = ud.idDisciplina";
        $sql .= " INNER JOIN turma_disciplina AS td ON td.idDisciplina = ud.idDisciplina";
        $sql .= " INNER JOIN turma AS t ON t.idTurma = td.idTurma";
        $sql .= " WHERE ud.idUsuario = '$idUsuario' ORDER BY t.ciclo, t.turma, d.nomeDisciplina";
        
        
        $resultado = mysqli_query($conexao, $sql);
        
        return $resultado;
        mysqli_close($conexao);
    }
    
    function inserirFormacaoDocente($idUsuario, $idDisciplina){
        global $conexao;
        
        $sql = " INSERT INTO docente_disciplina (idUsuario, idDisciplina) VALUES ('$idUsuario', '$idDisciplina')";
 
        return mysqli_query($conexao, $sql);
        mysqli_close($conexao);
    }
    
    function deletarUsuario($idUsuario){
        global $conexao;
        
        $sql = " DELETE FROM usuario WHERE idUsuario=".$idUsuario;
        
        return mysqli_query($conexao, $sql);
        mysqli_close($conexao);
    }
    
    function deletarDisciplinaDocente($idUsuario, $idDisciplina){
        global $conexao;
        
        $sql = " DELETE FROM docente_disciplina WHERE idUsuario=".$idUsuario;
        $sql .= " AND idDisciplina=".$idDisciplina;
        
        return mysqli_query($conexao, $sql);
        mysqli_close($conexao);
    }
    
    function deletarDocenteDisciplina($idUsuario){
        global $conexao;
        
        $sql = " DELETE FROM docente_disciplina WHERE idUsuario=".$idUsuario;

        return mysqli_query($conexao, $sql);
        mysqli_close($conexao);
    }
?>