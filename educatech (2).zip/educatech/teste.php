<?php 
    error_reporting(E_ALL & ~E_NOTICE);
    ini_set("display_errors", 1);
    
    require_once('modulos/bancoConexao.php');

    $conexao = conectarBanco();
    
    $idTurma = 3;

    $selectTurmaDisciplina = " SELECT * FROM turma_disciplina WHERE idTurma=".$idTurma;
    
    echo($selectTurmaDisciplina);
    
    $resultado = mysqli_query($conexao, $sql);
        
    if(mysqli_num_rows($resultado)  == 1){
		$gradeTurma = mysqli_fetch_array($resultado);
        echo($gradeTurma['idTurma']);
    } else {
        echo('Sem registro');
    }
        


    
    
?>

