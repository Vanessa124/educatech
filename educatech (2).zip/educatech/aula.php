<!DOCTYPE html>
<html lang="pt">
    <head>
        <title> EducaTech - Nova aula </title>
        <meta charset="utf-8">
        <link rel="stylesheet" href='css/style.css' type="text/css">
        <link rel="icon" type="image/png" href='imagens/icons8-escola-40.png'>
        <script src="js/jquery.min.js"></script>
        <script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/jquery-ui.min.js'> </script>
        
    </head>

    <body id='body-fundo-escuro'>
        
        <div id='cabecalho'>
            <div id="container-cabecalho">
                <div class='coluna-01' id='cabecalho-img'>
                    <img src='imagens/icons8-escola-40.png'>
                </div>
                <div class='coluna-05' id='cabecalho-titulo'>
                    EducaTech
                </div>
                
                <div class='coluna-01 cabecalho-icones'>
                    <img src='imagens/usuario.png'>
                </div>
                
                <div class='coluna-03' id='cabecalho-nome-usuario'>
                    Nome do usuário
                </div>
                
                <div class='coluna-01 cabecalho-icones'>
                    <img src='imagens/sair.png' title='Sair' id='sair-sistema'>
                </div>
                
                <div class='coluna-01'>
                    Sair 
                </div>
                
            </div>
        </div>
        
        <div id='container-branco'>
            <form name='formCadAula' method="post">
                <div class='linha header-titulo'>
                    Aula do dia 22/03/23
                </div>
                
                <div class='linha labels'>
                    <label for='txtResumoAula'> Resumo da aula: </label>
                </div>
                
                <div class='linha'>
                    <textarea name='txtResumoAula' required class='textarea'> </textarea>
                </div>
                
                <div class='linha labels'>
                    <label for='txtTarefa'> Tarefa (opcional): </label>
                </div>
                
                <div class='linha'>
                    <textarea name='txtTarefa' required class='textarea'> </textarea>
                </div>
                
                <div class='linha' id='header-tabela-presenca'>
                    Lista de presença
                </div>

                <div id='lista-presenca'>
                    <div class='linha-tabela-aluno'>
                        <div class='coluna-04'>
                            <strong> R.A </strong>
                        </div>

                        <div class='coluna-06'>
                            Nome completo do aluno
                        </div>

                        <div class='coluna-02'>
                            <input type='checkbox' name="presenca-aluno" value="">
                            <span class="checkmark"></span>
                        </div>
                    </div>   
                </div>
                
                <div class='linha'>
                    <input type='submit' name='btnSalvar' class='btn-cad-escola'  value="Salvar dados">
                </div>
            </form>
            
        </div>
        
    </body>
</html>