<?php 
    error_reporting(E_ALL & ~E_NOTICE);
    ini_set("display_errors", 1);
    require_once('modulos/usuario.php'); 

?>

<!DOCTYPE html>
<html lang="pt">
    <head>
        <title> EducaTech - Minhas turmas </title>
        <meta charset="utf-8">
        <link rel="stylesheet" href='css/style.css' type="text/css">
        <link rel="icon" type="image/png" href='imagens/icons8-escola-40.png'>
        <script src="js/jquery.min.js"></script>
        
        
    </head>

    <body id='body-fundo-escuro'>
        
        <div id='cabecalho'>
            <?php require_once('cabecalho-usuario.php') ?>
        </div>
        
        <div id='container-branco'>
            <div class='linha header-titulo'>
                Turmas lecionadas
            </div>
            
            <?php 
                $lista = selecionarTurmasLecionadas($usuario['idUsuario']);
            
                if(!mysqli_num_rows($lista) == 0){

                    while($turma = mysqli_fetch_array($lista)){ 
                        $text = $turma['ciclo']."º ";
                        $text .= $turma['turma'];
                        $url= "idTurma=".$turma['idTurma'];
                        $url .= "&idDisciplina=".$turma['idDisciplina'];;
            ?>

                        <div class='linha linha-borda-prof'>
                            <div class='col-lista-prof'>
                                <a href='lista-aulas.php?<?php echo($url); ?>' target="_blank" class='link-azul'>
                                    <?php echo($text); ?>
                                </a>
                            </div>

                            <div class='col-10-lista'>
                                <strong> Disciplina:  </strong> <?php echo($turma['nomeDisciplina']); ?>
                            </div>
                        </div>
            
            <?php  
                    
                    }
                } else {
                    echo("<div class='linha'>");
                    echo("Nenhum cadastro encontrado.");
                    echo("</div>");
                }
            
            ?>
            
        </div>
        

    </body>
</html>