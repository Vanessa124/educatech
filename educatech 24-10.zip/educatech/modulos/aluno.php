<?php
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    
    require_once('bancoConexao.php');

    $conexao = conectarBanco();
    
    function buscarAlunoPorRA($raAluno){
        global $conexao;
        
        $sql = "SELECT * FROM aluno WHERE raAluno = ".$raAluno;
        $select = mysqli_query($conexao, $sql);
        
        if(mysqli_num_rows($select) == 1){
			$aluno = mysqli_fetch_array($select);
            return $aluno;
        } else {
            return null;
        }
    }
    
    function inserirAluno($raAluno, $nomeAluno, $dataNascimento, $idTurma){
        global $conexao;
        
        $sql = "INSERT INTO aluno (raAluno, nomeAluno, dataNascimento, idTurma)";
        $sql .= " VALUES('$raAluno', '$nomeAluno', '$dataNascimento', '$idTurma')";
        return mysqli_query($conexao, $sql);
    	mysqli_close($conexao);
    }

    function editarDadosAluno($raAluno, $nomeAluno, $dataNascimento, $idTurma){
        global $conexao;
        
        $sql = "UPDATE aluno SET nomeAluno='.$nomeAluno.', dataNascimento='.$dataNascimento.', idTurma=".$idTurma;
        $sql.=" WHERE raAluno ='.$raAluno.'";
        
        return $sql;
        mysqli_query($conexao, $sql);
    	mysqli_close($conexao);
    }
    
    function deletarAluno($raAluno){
        global $conexao;
        
        $sql = " DELETE FROM aluno WHERE raAluno=".$raAluno;
        
        return mysqli_query($conexao, $sql);
        mysqli_close($conexao);
    }
    
    function consultarAlunosPorTurma($idTurma){
        global $conexao;
        
        $sql = "SELECT * FROM aluno WHERE idTurma='$idTurma' ORDER BY nomeAluno ASC ";
        
        return mysqli_query($conexao, $sql);
        
        mysqli_close($conexao);
    }

    function consultarAlunosPorEscola($idEscola){
        global $conexao;
        
        $sql = "SELECT aluno.*, t.ciclo, t.turma FROM `aluno`";
        $sql.= " INNER JOIN turma AS t ON t.idTurma = aluno.idTurma";
        $sql.= " WHERE idEscola='$idEscola' ORDER BY ciclo, turma, nomeAluno ASC ";
        
        return mysqli_query($conexao, $sql);
        
        mysqli_close($conexao);
    }

    function autenticarUsuario($raAluno, $dataNascimento){
        global $conexao;
        
        $sql = "SELECT * FROM aluno WHERE raAluno = '$raAluno' AND dataNascimento = '$dataNascimento'";
        
        $select = mysqli_query($conexao, $sql);
        
        if(mysqli_num_rows($select) == 1){
            $aluno = mysqli_fetch_array($select);
            return $aluno;
        } else {
            return null;
        }
        
        mysqli_close($conexao);
    }
    

?>