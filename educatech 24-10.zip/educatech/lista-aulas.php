<?php 
    error_reporting(E_ALL & ~E_NOTICE);
    ini_set("display_errors", 1);

    require_once('modulos/turma.php');

    $idTurma = $_GET['idTurma'];
    $idDisciplina = $_GET['idDisciplina'];

?>

<!DOCTYPE html>
<html lang="pt">
    <head>
        <title>  EducaTech - Todas as aulas</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href='css/style.css' type="text/css">
        <link rel="icon" type="image/png" href='imagens/icons8-escola-40.png'>
        <script src="js/jquery.min.js"></script>
        <script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/jquery-ui.min.js'> </script>
        
    </head>
    
    <script>
        function abrirFormNomeUser(){
            $('#formNomeUser').show();
        }
              
        function fecharFormNomeUser(){
            $('#formNomeUser').hide();
        }
        
    </script>
    
    <body id='body-fundo-escuro'>
        
        <div id='cabecalho'>
            <?php require_once('cabecalho-usuario.php') ?>
        </div>
        
        <div id='container-branco'>
            
            <div class='linha'>
                <strong> Turma:  </strong> 6º B 
            </div>

	       <div class='linha'>
                 <strong> Disciplina: </strong> Matemática
            </div>
            
            <?php 
                if($usuario['tipoUsuario'] == "docente"){ ?>
                    <div class='linha linha-link-aula'>
                        <strong> Links: </strong>

                        <a href='aula.php' target="_blank" class='link-aula'>
                            Novo registro de aula
                        </a>

                        <a href='' target="_blank" class='link-aula'>
                            Atribuir média dos alunos
                        </a>
                    </div>
            <?php    } ?>
            
            <div class='linha header-titulo'>
                Aulas registradas
            </div>

            <div class='linha-aulas'>
                
                <div class='linha'>
                    <strong> Data: </strong> 09/05/23
                </div>
                
                <div class='linha'>
                    Apresentação do conceito e resolução de problemas com números decimais, fracionários e racionais
                </div>

            </div>
            
            <div class='linha-aulas ultima-linha-aulas'>
                
                <div class='linha'>
                    <strong> Data: </strong> 13/05/23
                </div>
                
                <div class='linha'>
                    Foi passado mais exercícios sobre problema decimais para reforçar o aprendizado dos alunos e foi feito a correção dos exercícios da apostila. 
                </div>

            </div>
        

            <div class='linha header-titulo'>
                Lista de tarefas
            </div>
            
            <div class='linha-tarefas ultima-linha-aulas'>
                
                <div class='linha'>
                    <strong> Data de vencimento:  </strong> 13/05/23  
                </div>
                
                <div class='linha'>
                    Exercício 1, 2 e 3 da apostila pagína 27
                </div>
		
		        <div class='linha'>
                    <strong> Referente a aula do dia 09/05/23  </strong>
                </div>

            </div>
            
            <div class='linha header-titulo'>
                Comentários
            </div>
            
            <div class='linha-comentarios ultima-linha-aulas'>
                <div class='linha'>
                    <div class='coluna-03'>
                        <strong> Data:  </strong> 15/05/23
                    </div>
                    
                    <div class='coluna-09'>
                        <strong> Nome:  </strong> Patricia (responsável do aluno HUMBERTO DIAS)
                    </div>
                </div>
                
                <div class='linha'>
                    Meu filho não pode ir a aula no qual foi passado o conteúdo, ajudei a resolver os exercícios e ele ira entregar na próxima aula junto com o atestado médico. 
                </div>
            </div>
            
            <div class='linha'>
                <strong> Novo comentário </strong> 
            </div>
            
            <form name='formComentario' method="post" id='formComentario'>
                
                 <?php 
                    if(!$usuario['tipoUsuario'] == "docente"){ ?>
 
                        <div class='linha labels'>
                             Comentar como: 
                        </div>

                        <div class='linha'>
                            <div class='coluna-04'>
                                <label class="input-radio"> Aluno (a)
                                  <input type="radio" name="tipoUserComentario" value="aluno" onclick="fecharFormNomeUser()">
                                  <span class="radio-checked"></span>
                                </label>
                            </div>

                            <div class='coluna-04'>
                                <label class="input-radio"> Responsavel 
                                  <input type="radio" name="tipoUserComentario" value='responsavel' onclick="abrirFormNomeUser()">
                                  <span class="radio-checked"></span>
                                </label>  
                            </div>
                        </div>
                <?php  } ?>

                <div class='linha' id='formNomeUser'>
                    <div class='linha labels'>
                        <label for='txtUserComentario'> Nome: </label>
                    </div>

                    <div class='linha'>
                        <input type='text' name='txtUserComentario' class='inputs inputs-cad-usuario'  maxlength="30"> 
                    </div>
                </div>

                <div class='linha labels'>
                    Mensagem: 
                </div>

                <div class='linha'>
                    <textarea name='txtComentario' required id='textarea-comentario'> </textarea>
                </div>
                
                <div class='linha'>
                    <input type='submit' name='btnSalvar' id='btn-cad-comentario'  value="Adicionar novo comentário">
                </div>
            </form>
        </div>
    
    </body>
</html>